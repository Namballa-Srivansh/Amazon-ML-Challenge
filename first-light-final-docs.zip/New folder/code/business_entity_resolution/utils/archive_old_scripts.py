"""
archive_old_scripts.py
========================
One-time cleanup: moves the two inference scripts that v10_final_ensemble.py
supersedes into archive/, so src/ only contains the scripts that are part of
the current, working pipeline.

Why archive instead of delete: both files are a real part of the project's
history (generate_v3_submission.py got a working v3-based path running early;
v9_final_ensemble.py is where the memory-architecture problems that motivated
v10 were actually discovered and fought through, chunk-explosion by
chunk-explosion). Deleting them would erase that trail for no benefit --
archiving keeps the repo clean without losing the story.

Run from anywhere; paths are resolved relative to this file's location.
    python utils/archive_old_scripts.py
"""
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)   # code/business_entity_resolution/
SRC  = os.path.join(ROOT, "src")
ARCHIVE = os.path.join(ROOT, "archive")

TO_ARCHIVE = ["v9_final_ensemble.py", "generate_v3_submission.py"]

def main():
    os.makedirs(ARCHIVE, exist_ok=True)
    for fname in TO_ARCHIVE:
        src_path = os.path.join(SRC, fname)
        dst_path = os.path.join(ARCHIVE, fname)
        if not os.path.exists(src_path):
            print(f"  skip (not found in src/): {fname}")
            continue
        if os.path.exists(dst_path):
            print(f"  skip (already in archive/): {fname}")
            continue
        shutil.move(src_path, dst_path)
        print(f"  moved: src/{fname} -> archive/{fname}")

    pycache = os.path.join(SRC, "__pycache__")
    if os.path.isdir(pycache):
        shutil.rmtree(pycache)
        print(f"  removed: src/__pycache__/")

    print("\nDone. src/ now contains only the scripts that make up the current pipeline.")
    print("See archive/README.md for why these two files are kept around.")

if __name__ == "__main__":
    main()
