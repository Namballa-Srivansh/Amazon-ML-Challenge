# Archive

These two scripts are **superseded** by `src/v10_final_ensemble.py` and are
kept here for the project history, not for use.

## `v9_final_ensemble.py`

The version that ran into the memory-architecture wall the whole project
pivoted around: an in-memory embedding dict (~22GB for the full S23 corpus),
unbounded `pandas.merge()`-based blocking (one shared key produced an
86-million-row intermediate on a single 5,000-row chunk), and full-run
result accumulation in a Python list. Every fix attempted on this file —
smaller chunks, lower hot-key caps, `gc.collect()` calls — treated a
symptom; none of them changed the fact that the underlying design assumed
unlimited RAM. `v10_final_ensemble.py` replaces the merge with a capped
inverted index and the in-memory dict with a disk-backed SQLite store,
which is why it doesn't need any of these workarounds.

## `generate_v3_submission.py`

An earlier, simpler standalone inference path built around the v3 Logistic
Regression classifier (9 features, no embeddings, no Double Metaphone
blocking). It never hit the v9 failure modes because its blocking was
already naturally bounded (word + Soundex + acronym keys only) — worth
keeping as a reference for how much simpler the pipeline was before
Double Metaphone blocking and XGBoost were added in v6.

Neither file should be run as part of the current pipeline. Use
`src/v10_final_ensemble.py`.
